# Wynde UX Guide bilingual content package

This package contains the Russian and English guide content plus i18n-ready content helpers.

## Files

- `content/guide-structure.ru.json` — original Russian source.
- `content/guide-structure.en.json` — full English translation.
- `content/guideStructure.ts` — locale-aware structure loader.
- `content/guide.ts` — locale-aware guide adapter, with content hardcode removed.
- `content/guide-structure.i18n.test.mjs` — structural parity tests for RU/EN.
- `wynde-guide-i18n-codex-prompt.md` — implementation prompt for Codex.

## Validation already run

- RU and EN have the same structure.
- Both locales have 12 top-level chapters.
- Both locales have 76 headings.
- Both locales have 673 content blocks.
- All 734 localizable fields were translated: `source.title`, heading `title`, and block `text`.
- EN titles/text fields contain no Cyrillic characters.
