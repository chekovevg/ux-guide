import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const ru = JSON.parse(
  await readFile(new URL("./guide-structure.ru.json", import.meta.url), "utf8"),
);
const en = JSON.parse(
  await readFile(new URL("./guide-structure.en.json", import.meta.url), "utf8"),
);

function flattenHeadings(nodes) {
  return nodes.flatMap((node) => [node, ...flattenHeadings(node.children ?? [])]);
}

function flattenBlocks(nodes) {
  return nodes.flatMap((node) => [
    ...(node.blocks ?? []),
    ...flattenBlocks(node.children ?? []),
  ]);
}

function structuralSnapshot(nodes) {
  return nodes.map((node) => ({
    slug: node.slug,
    level: node.level,
    notionBlockType: node.notionBlockType,
    sourceBlockIndex: node.sourceBlockIndex,
    blocks: (node.blocks ?? []).map((block) => ({
      type: block.type,
      sourceBlockIndex: block.sourceBlockIndex,
      image: block.image,
    })),
    children: structuralSnapshot(node.children ?? []),
  }));
}

function localizedStrings(nodes) {
  const values = [];

  for (const node of nodes) {
    values.push(node.title);

    for (const block of node.blocks ?? []) {
      if (block.text) {
        values.push(block.text);
      }
    }

    values.push(...localizedStrings(node.children ?? []));
  }

  return values;
}

test("stores RU and EN guide structures with the same backend-ready shape", () => {
  assert.equal(ru.schemaVersion, 2);
  assert.equal(en.schemaVersion, 2);
  assert.equal(ru.source.notionPageId, en.source.notionPageId);
  assert.equal(ru.chapters.length, 12);
  assert.equal(en.chapters.length, 12);
  assert.deepEqual(structuralSnapshot(en.chapters), structuralSnapshot(ru.chapters));
});

test("keeps stable unique slugs for all locales", () => {
  for (const structure of [ru, en]) {
    const headings = flattenHeadings(structure.chapters);
    const slugs = headings.map((heading) => heading.slug);

    assert.equal(new Set(slugs).size, slugs.length);
    assert.ok(slugs.every((slug) => /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)));
    assert.ok(slugs.includes("intro"));
    assert.ok(slugs.includes("nemoderiruemoe-stsenarnoe-testirovanie"));
    assert.ok(slugs.includes("shag-4-nastroyte-demokratizatsiyu"));
  }
});

test("keeps body block counts aligned between locales", () => {
  const ruBlocks = flattenBlocks(ru.chapters);
  const enBlocks = flattenBlocks(en.chapters);

  assert.ok(ruBlocks.length > 600);
  assert.equal(enBlocks.length, ruBlocks.length);
});

test("has translated EN titles and text fields", () => {
  const enStrings = localizedStrings(en.chapters).join("\n");

  assert.match(en.source.title, /UX|research|guide/i);
  assert.doesNotMatch(enStrings, /[А-Яа-яЁё]/);
});
