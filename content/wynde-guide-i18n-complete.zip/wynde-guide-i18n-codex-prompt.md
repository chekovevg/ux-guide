Ты работаешь в проекте `D:/Codex/UX Guide Wynde`.

Задача: перевести гайд на английский и подготовить контентную архитектуру под будущий переключатель языка. Важно: контент глав должен браться из одного уровня источника данных, без ручного хардкода текста в `content/guide.ts`.

Текущий контекст:
- Основной контент сейчас лежит в `content/guide-structure.json`.
- Он импортируется в `content/guideStructure.ts`.
- В `content/guide.ts` структура преобразуется в формат компонентов.
- Страницы берут главы через `getGuideChapter` в `app/guide/[slug]/page.tsx`.
- В `content/guide.ts` сейчас есть хардкод/оверрайд для главы `soprotivlenie-issledovaniyam-i-kak-s-etim-rabotat`. Его нужно убрать как источник контента или перенести в языковые JSON-источники. Не должно остаться английских/русских текстовых блоков, зашитых прямо в `guide.ts`, кроме UI-метаданных вроде coverImage, если они действительно не являются контентом гайда.

Что нужно сделать:

1. Разнести контент по языкам
- Сохрани текущий русский контент как `content/guide-structure.ru.json`.
- Создай английскую версию `content/guide-structure.en.json`.
- Оба файла должны иметь одинаковую структуру:
  - одинаковые `schemaVersion`;
  - одинаковое дерево `chapters`;
  - одинаковые `slug`;
  - одинаковые `level`, `notionBlockType`, `sourceBlockIndex`;
  - одинаковый порядок глав, секций и блоков;
  - одинаковые `type` у блоков;
  - одинаковые `image`, URL и data URI.
- В английской версии переводи только пользовательский текст:
  - `source.title`;
  - `title` у всех heading/chapter/section nodes;
  - `text` у всех blocks.
- Не переводи:
  - `slug`;
  - `image`;
  - URL;
  - `notionPageId`;
  - `sourceBlockIndex`;
  - `type`;
  - `notionBlockType`;
  - технические названия брендов/продуктов: `Pathway`, `Figma`, `AI`, `UX`, `A/B`, `Live website`, `Help Center`, `Product–market fit`, если они уже естественно звучат по-английски.
- Русскую версию не переписывай стилистически, просто перенеси текущий JSON как baseline.

2. Перевод на английский
- Переводи естественно, как продуктовый UX-гайд, а не дословно.
- Тон: ясный, практичный, дружелюбный, профессиональный.
- Сохраняй смысл, структуру и порядок мыслей.
- Исправляй очевидные склейки из Notion при переводе:
  - `Пример с рынкаSun Microsystems...` → `Market example: Sun Microsystems...`
  - `Pro-tipПеред...` → `Pro tip: Before...`
  - похожие склейки заголовка и текста тоже аккуратно разделяй в английском тексте.
- Плейсхолдеры тоже переводи:
  - `[добавить цифру]` → `[add number]`
  - `Подробнее ... →` → `Learn more ... →`
- Не добавляй новые факты и не проверяй источники. Это только перевод и i18n-рефакторинг существующего контента.

3. Обновить `content/guideStructure.ts`
Сделай поддержку локали:
- Добавь тип:
  - `export type GuideLocale = "ru" | "en";`
  - `export const defaultGuideLocale: GuideLocale = "ru";`
- Импортируй оба JSON:
  - `guide-structure.ru.json`
  - `guide-structure.en.json`
- Экспортируй:
  - `guideStructures`
  - `getGuideStructure(locale = defaultGuideLocale)`
  - `getGuideStructureChapters(locale = defaultGuideLocale)`
  - `getGuideStructureChapter(slug, locale = defaultGuideLocale)`
  - `getGuideStructureNavigation(activeSlug, availableSlugs, locale = defaultGuideLocale)`
- Оставь обратную совместимость:
  - `guideStructure` и `guideStructureChapters` должны продолжать работать как русская/default версия.
- Навигация должна брать `title` из выбранной локали, но `slug` оставлять стабильным.

4. Обновить `content/guide.ts`
- `getGuideChapter` должен принимать локаль:
  - `getGuideChapter(slug: string, locale: GuideLocale = defaultGuideLocale)`
- `getGuideNavigation` должен принимать локаль:
  - `getGuideNavigation(activeSlug: string, locale: GuideLocale = defaultGuideLocale)`
- Добавь `getGuideChapters(locale = defaultGuideLocale)`.
- Сохрани старый экспорт `guideChapters` как default/RU, чтобы не сломать текущие места использования.
- Убери текущий hardcoded override для главы про сопротивление исследованиям:
  - `resistanceIntro`
  - `resistanceSections`
  - ранний `return` внутри `structureChapterToGuideChapter`
- Если cover image для resistance нужен, оставь только UI-метаданные по `slug`, но не текстовый контент главы.
- `updatedAt` должен быть локализован:
  - RU: `Обновлено DD.MM.YYYY`
  - EN: `Updated Month D, YYYY`

5. Подготовить страницу к будущему переключателю языка
- Если `app/guide/[slug]/page.tsx` сейчас вызывает `getGuideChapter(slug)`, оставь default RU поведение без поломок.
- По возможности добавь поддержку `?lang=en` / `?lang=ru` через `searchParams`, но только если это не ломает текущий роутинг.
- Если страница сейчас не готова к `searchParams`, не делай большой роутинг-рефакторинг. Достаточно подготовить data layer, чтобы позже можно было подключить полноценный переключатель.

6. Обновить тесты
Обнови `content/guide-structure.test.mjs` или добавь новый тест:
- Проверить, что `guide-structure.ru.json` и `guide-structure.en.json` имеют одинаковое дерево:
  - одинаковые slugs;
  - одинаковые уровни;
  - одинаковые block types;
  - одинаковые `sourceBlockIndex`;
  - одинаковое количество headings и blocks.
- Проверить, что в RU 12 глав.
- Проверить, что в EN тоже 12 глав.
- Проверить, что EN сохраняет стабильные slug, например:
  - `intro`
  - `nemoderiruemoe-stsenarnoe-testirovanie`
  - `shag-4-nastroyte-demokratizatsiyu`
- Проверить, что в EN нет кириллицы в `title` и `text` полях. Исключение: не проверять `image`/URL/data URI.
- Проверить, что `getGuideStructureNavigation(..., "en")` возвращает английские заголовки, но те же slug.
- Запусти тесты.

Acceptance criteria:
- Контент больше не живёт в `guide.ts`, кроме преобразования структуры в компоненты и небольших UI-метаданных.
- Русский гайд остаётся доступен как default.
- Английский гайд доступен через те же slug и ту же структуру.
- Все текущие страницы продолжают работать.
- В будущем можно подключить language switcher без повторного рефакторинга контента.
- Тесты проходят.
